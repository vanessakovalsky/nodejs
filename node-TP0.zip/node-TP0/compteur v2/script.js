let maSpan=document.querySelector('div span')
let cpt=0
document.getElementById("btnRaz").addEventListener("click", function () {
	cpt=0;
	maSpan.textContent=cpt
});
document.getElementById("btnCompter").addEventListener("click", function () {
	cpt+=1
	maSpan.textContent=cpt
});