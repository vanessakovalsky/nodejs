document.getElementById("btnRaz").addEventListener("click", function () {
	document.querySelector('div span').textContent=0
});
document.getElementById("btnCompter").addEventListener("click", function () {
	let cpt=parseInt(document.querySelector('div span').textContent)
	document.querySelector('div span').textContent=cpt+1
});